#include <iostream>
#include <vector>
#include <algorithm> // Para std::find_if

class Persona {
public:
    std::string nombre;
    int edad;

    Persona(const std::string &nombre, int edad) : nombre(nombre), edad(edad) {}
    Persona() : nombre(""), edad(0) {}
    virtual void mostrarDatos() const {
        std::cout << "Nombre: " << nombre << ", ";
        std::cout << "Edad: " << edad << std::endl;
    }

    // Sobrecarga de operador ==
    bool operator==(const Persona &other) const {
        return nombre == other.nombre && edad == other.edad;
    }

    // Sobrecarga de operador !=
    bool operator!=(const Persona &other) const {
        return !(*this == other);
    }

    // Sobrecarga del operador <<
    friend std::ostream& operator<<(std::ostream& os, const Persona& persona) {
        os << "Nombre: " << persona.nombre << ", ";
        os << "Edad: " << persona.edad;
        return os;
    }
};

class Alumno : public Persona {
private:
    std::string universidad;
    std::string carrera;

public:
    Alumno(const std::string &nombre, int edad, const std::string &universidad, const std::string &carrera)
        : Persona(nombre, edad), universidad(universidad), carrera(carrera) {}

    void mostrarDatos() const override {
        Persona::mostrarDatos();
        std::cout << "Universidad: " << universidad << ", ";
        std::cout << "Carrera: " << carrera << std::endl;
    }
};

class Profesor : public Persona {
private:
    std::string departamento;

public:
    Profesor(const std::string &nombre, int edad, const std::string &departamento)
        : Persona(nombre, edad), departamento(departamento) {}

    void mostrarDatos() const override {
        Persona::mostrarDatos();
        std::cout << "Departamento: " << departamento << std::endl;
    }
};
void printMenu();
void darDeAlta(std::vector<Persona*> &personas);
void buscarPersona(const std::vector<Persona*> &personas);
void darDeBaja(std::vector<Persona*> &personas);
void mostrarTodosLosDatos(const std::vector<Persona*> &personas);
