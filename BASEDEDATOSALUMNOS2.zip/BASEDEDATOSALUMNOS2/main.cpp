#include <iostream>
#include <vector>
#include <algorithm> // Para std::find_if
#include "Alumno.h"
#include <windows.h>
#include <sstream>
#include <windows.h>
#include <string>
#define ID1 1001
#define ID2 1002
#define ID3 1003
#define ID4 1004
#define ID5 1005
#define ID_AGREGAR_PERSONA 1006
//Variables Globales
HWND hwndNombreEdit, hwndEdadEdit, hwndButton, hwndTipoEdit;
std::vector<Persona> personas;
int salir = 0;
//Procedimiento de la ventana IN
LRESULT CALLBACK WindowProcVentanaIn(HWND hwndDATOSIN, UINT uMsg, WPARAM wParam, LPARAM lParam){
    switch (uMsg) {
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case ID_AGREGAR_PERSONA:
                    DestroyWindow(hwndDATOSIN);
                    //std::vector<Persona*> personas;
                        // Si se presiona el bot�n "Agregar Persona"
                            wchar_t nombreBuffer[256];
                            GetWindowTextW(hwndNombreEdit, nombreBuffer, 256);
                            std::wstring nombreWideString(nombreBuffer);
                            std::string nombre(nombreWideString.begin(), nombreWideString.end());
                            // Obtener texto ingresado en el cuadro de texto de la edad
                            wchar_t edadBuffer[256];
                            GetWindowTextW(hwndEdadEdit, edadBuffer, 256);
                            int edad = _wtoi(edadBuffer);
                            // Crear objeto Persona y agregarlo al vector
                             // Crear objeto Persona y agregarlo al vector
                            Persona nuevaPersona;
                            nuevaPersona.nombre = nombre;
                            nuevaPersona.edad = edad;
                            // Agregar el objeto Persona al vector personas
                            personas.push_back(nuevaPersona);
                            // Limpiar los cuadros de texto
                            //SetWindowTextW(GetDlgItem(hwndDATOSIN, 0), L"");
                            //SetWindowTextW(GetDlgItem(hwndDATOSIN, 1), L"");
                            for (const auto& persona : personas) {
                                        std::cout << "Nombre: " << persona.nombre << ", Edad: " << persona.edad << std::endl;
                                }
                        salir =0;
                        break;
                        DestroyWindow(hwndDATOSIN);
            }
            break;
            case WM_CLOSE:
                DestroyWindow(hwndDATOSIN);
                salir = 5;
                    break;
            case WM_DESTROY:
                PostQuitMessage(0);
                    break;
            default:
                return DefWindowProc(hwndDATOSIN, uMsg, wParam, lParam);
                }
                return 0;
}
// Procedimiento de la ventana principal
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case ID1:
                    DestroyWindow(hwnd);
                    salir = 1;
                    break;
                case ID2:
                    DestroyWindow(hwnd);
                   // buscarPersona(personas);
                    salir = 2;
                    break;
                case ID3:
                    DestroyWindow(hwnd);
                    //darDeBaja(personas);
                    salir = 3;
                    break;
                case ID4:
                    DestroyWindow(hwnd);
                    //mostrarTodosLosDatos(personas);
                    salir = 4;
                    break;
                case ID5:
                    salir = 5;
                   DestroyWindow(hwnd);
                    break;
            }
            break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            salir = 5;
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    do{// Declarar la variable hwnd
    HWND hwnd;
    HWND hwndDATOSIN;
    // Registrar la clase de la ventana
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "MyWindowClass";
    RegisterClass(&wc);
    // Registrar la clase ventanadatosin
    WNDCLASS wcDatosIn = {0}; // Para la ventana "MyWindowClassDATOSIN"
    wcDatosIn.lpfnWndProc = WindowProcVentanaIn;
    wcDatosIn.hInstance = hInstance;
    wcDatosIn.lpszClassName = "MyWindowClassDATOSIN";
    RegisterClass(&wcDatosIn);

    // Crear la ventanadatosin
    hwndDATOSIN = CreateWindowEx(0,"MyWindowClassDATOSIN","Menu",WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 1000, 800,NULL,NULL,hInstance,NULL);
        CreateWindowW(L"Static",L"Ingrese su nombre : ",WS_VISIBLE | WS_CHILD , 100,32,150,20,hwndDATOSIN,NULL,hInstance,NULL);
        CreateWindowW(L"Static",L"Ingrese su nombre : ",WS_VISIBLE | WS_CHILD , 100,32,150,20,hwndDATOSIN,NULL,NULL,NULL);
        hwndNombreEdit = CreateWindowW(L"Edit", NULL,WS_VISIBLE | WS_CHILD | WS_BORDER, 100, 50, 200, 25, hwndDATOSIN, NULL, hInstance, NULL);
        CreateWindowW(L"Static",L"Ingrese su edad : ",WS_VISIBLE | WS_CHILD , 100,77,150,20,hwndDATOSIN,NULL,NULL,NULL);
        hwndEdadEdit = CreateWindowW(L"Edit", NULL,WS_VISIBLE | WS_CHILD | ES_NUMBER | WS_BORDER, 100, 100, 200, 25, hwndDATOSIN, NULL, hInstance, NULL);
        hwndButton = CreateWindowW(L"Button", L"Agregar Persona",WS_VISIBLE | WS_CHILD, 100, 125, 120, 40, hwndDATOSIN, (HMENU)ID_AGREGAR_PERSONA, hInstance, NULL);
    //crear ventana
    hwnd = CreateWindowEx(0,"MyWindowClass","Menu",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT, CW_USEDEFAULT, 1000, 800,NULL,NULL,hInstance,NULL);
        CreateWindow("STATIC","=================Men�===================\n                                /(_M_)\\\n                               (_       _)\n                                 \\/-V-\\/\nSelecciona una opci�n:",WS_CHILD | WS_VISIBLE,350, 50, 300, 100,hwnd,NULL,hInstance,NULL);
        CreateWindow("BUTTON","Dar de alta",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,450, 150, 100, 30,hwnd,(HMENU)ID1,hInstance,NULL);
        CreateWindow("BUTTON","Buscar",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,350, 150, 100, 30,hwnd,(HMENU)ID2,hInstance,NULL);
        CreateWindow("BUTTON","Dar de baja",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,550, 150, 100, 30,hwnd,(HMENU)ID3,hInstance,NULL);
        CreateWindow("BUTTON","Mostrar Datos",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,350, 180, 100, 30,hwnd,(HMENU)ID4,hInstance,NULL);
        CreateWindow("BUTTON","Salir",WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,450, 180, 100, 30,hwnd,(HMENU)ID5,hInstance,NULL);

    // Mostrar la ventana
    if(salir==0){
        ShowWindow(hwnd, nCmdShow);
    }
    if(salir==1){
        ShowWindow(hwndDATOSIN, nCmdShow);

    }
    // Bucle de mensajes
    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    }while(salir != 5);
    return 0;
}
