// Constructor
#include "Alumno.h"
#include<windows.h>


void darDeAlta(std::vector<Persona*> &personas) {

    std::string nombre;
    int edad;
    char tipo;

    std::cout << "Ingrese el nombre de la persona: ";
    std::getline(std::cin, nombre);
    std::cout << "Ingrese la edad de la persona: ";
    std::cin >> edad;
    std::cin.ignore(); // Limpiar el buffer de entrada

    std::cout << "Ingrese el tipo de persona (A para Alumno, P para Profesor): ";
    std::cin >> tipo;
    std::cin.ignore(); // Limpiar el buffer de entrada

    if (tipo == 'A') {
        std::string universidad, carrera;
        std::cout << "Ingrese la universidad del alumno: ";
        std::getline(std::cin, universidad);
        std::cout << "Ingrese la carrera del alumno: ";
        std::getline(std::cin, carrera);
        personas.push_back(new Alumno(nombre, edad, universidad, carrera));
    } else if (tipo == 'P') {
        std::string departamento;
        std::cout << "Ingrese el departamento del profesor: ";
        std::getline(std::cin, departamento);
        personas.push_back(new Profesor(nombre, edad, departamento));
    } else {
        std::cout << "Tipo de persona no v�lido." << std::endl;
    }

    std::cout << "Persona agregada exitosamente." << std::endl;
}

void buscarPersona(const std::vector<Persona*> &personas) {
    if (personas.empty()) {
        std::cout << "No hay personas registradas." << std::endl;
        return;
    }

    std::string nombre;
    std::cout << "Ingrese el nombre de la persona a buscar: ";
    std::getline(std::cin, nombre);

    bool encontrado = false;
    for (const auto &persona : personas) {
        if (persona->nombre == nombre) {
            persona->mostrarDatos();
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        std::cout << "Persona no encontrada." << std::endl;
    }
}

void darDeBaja(std::vector<Persona*> &personas) {
    if (personas.empty()) {
        std::cout << "No hay personas registradas." << std::endl;
        return;
    }

    std::string nombre;
    std::cout << "Ingrese el nombre de la persona a dar de baja: ";
    std::getline(std::cin, nombre);

    auto it = std::find_if(personas.begin(), personas.end(), [&](const Persona* persona) {
        return persona->nombre == nombre;
    });

    if (it != personas.end()) {
        delete *it;
        personas.erase(it);
        std::cout << "Persona dada de baja exitosamente." << std::endl;
    } else {
        std::cout << "Persona no encontrada." << std::endl;
    }
}

void mostrarTodosLosDatos(const std::vector<Persona*> &personas) {
    if (personas.empty()) {
        std::cout << "No hay personas registradas." << std::endl;
        return;
    }

    std::cout << "Lista de personas:" << std::endl;
    for (const auto &persona : personas) {
        std::cout << *persona << std::endl;
    }
}
